const axios = require('axios');
const Event = require('../models/Event');
const User = require('../models/User');

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

/**
 * Normalizes scraped categories into IzzoEvents standard categories
 */
function normalizeCategory(rawCat = '', title = '', desc = '') {
  const text = `${rawCat} ${title} ${desc}`.toLowerCase();
  if (text.includes('concert') || text.includes('music') || text.includes('live') || text.includes('album') || text.includes('band') || text.includes('sound')) {
    return 'Music & Concerts';
  }
  if (text.includes('night') || text.includes('party') || text.includes('dj') || text.includes('club') || text.includes('lounge') || text.includes('rave')) {
    return 'Nightlife & Parties';
  }
  if (text.includes('art') || text.includes('culture') || text.includes('festival') || text.includes('exhibition') || text.includes('theatre') || text.includes('cinema') || text.includes('fashion')) {
    return 'Arts, Culture & Festivals';
  }
  if (text.includes('tech') || text.includes('business') || text.includes('conference') || text.includes('summit') || text.includes('networking') || text.includes('forum') || text.includes('expo')) {
    return 'Business & Networking';
  }
  if (text.includes('sport') || text.includes('basketball') || text.includes('football') || text.includes('run') || text.includes('marathon') || text.includes('fitness') || text.includes('bal')) {
    return 'Sports & Fitness';
  }
  if (text.includes('workshop') || text.includes('education') || text.includes('seminar') || text.includes('training') || text.includes('masterclass')) {
    return 'Educational and Informational Events';
  }
  return 'Community & Social';
}

/**
 * 1. Scrape Events from BK Arena (https://bkarena.rw/events-2/)
 */
async function scrapeBkArena() {
  const events = [];
  try {
    console.log('[Aggregator] Fetching BK Arena events...');
    // 1st attempt: Check WordPress REST API
    try {
      const wpRes = await axios.get('https://bkarena.rw/wp-json/wp/v2/posts?per_page=15&_embed=1', {
        headers: { 'User-Agent': USER_AGENT },
        timeout: 10000
      });
      if (Array.isArray(wpRes.data) && wpRes.data.length > 0) {
        for (const item of wpRes.data) {
          const title = item.title?.rendered?.replace(/&#8211;/g, '-').replace(/&#8217;/g, "'").replace(/&amp;/g, '&') || 'BK Arena Event';
          const desc = item.excerpt?.rendered?.replace(/<[^>]*>/g, '').trim() || item.content?.rendered?.replace(/<[^>]*>/g, '').substring(0, 300) || 'Exciting event at BK Arena Kigali.';
          const link = item.link || 'https://bkarena.rw/events-2/';
          const media = item._embedded?.['wp:featuredmedia']?.[0]?.source_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80';
          
          let eventDate = new Date(item.date || Date.now());
          if (eventDate < new Date()) {
            // If post date is past, schedule for upcoming days
            eventDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
          }

          events.push({
            title: title.trim(),
            description: desc,
            venue: 'BK Arena, Kigali',
            category: normalizeCategory('Sports & Concerts', title, desc),
            date: eventDate,
            bannerImage: media,
            organizerName: 'BK Arena',
            price: 0,
            isTicketed: true,
            priceRange: 'Tickets at Entrance / Online',
            externalTicketLink: link,
            sourcePlatform: 'bkarena.rw',
            sourceUrl: link
          });
        }
      }
    } catch (wpErr) {
      console.warn('[Aggregator] BK Arena WP API fallback to HTML scraping:', wpErr.message);
    }

    // 2nd attempt: If no events found, fetch HTML page and parse
    if (events.length === 0) {
      const res = await axios.get('https://bkarena.rw/events-2/', {
        headers: { 'User-Agent': USER_AGENT },
        timeout: 12000
      });
      const html = res.data;

      // Extract image boxes or cards
      const cardRegex = /<div[^>]*class="[^"]*elementor-widget-image-box[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/gi;
      let match;
      while ((match = cardRegex.exec(html)) !== null) {
        const block = match[1];
        const titleMatch = /<h\d[^>]*class="[^"]*elementor-image-box-title[^"]*"[^>]*>(.*?)<\/h\d>/i.exec(block);
        const imgMatch = /<img[^>]*src="([^"]+)"/i.exec(block);
        const linkMatch = /<a[^>]*href="([^"]+)"/i.exec(block);

        if (titleMatch && titleMatch[1]) {
          const rawTitle = titleMatch[1].replace(/<[^>]*>/g, '').trim();
          if (rawTitle && rawTitle.length > 2) {
            events.push({
              title: rawTitle,
              description: `Upcoming live experience at BK Arena Kigali. Check out ${rawTitle} and book tickets online.`,
              venue: 'BK Arena, Kigali',
              category: normalizeCategory('', rawTitle, ''),
              date: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000),
              bannerImage: imgMatch ? imgMatch[1] : 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
              organizerName: 'BK Arena',
              price: 0,
              isTicketed: true,
              priceRange: 'See details on BK Arena',
              externalTicketLink: linkMatch ? linkMatch[1] : 'https://bkarena.rw/events-2/',
              sourcePlatform: 'bkarena.rw',
              sourceUrl: linkMatch ? linkMatch[1] : 'https://bkarena.rw/events-2/'
            });
          }
        }
      }
    }
  } catch (err) {
    console.error('[Aggregator] Error scraping BK Arena:', err.message);
  }
  return events;
}

/**
 * 2. Scrape Events from SINC Events (https://sinc.events/)
 */
async function scrapeSincEvents() {
  const events = [];
  try {
    console.log('[Aggregator] Fetching SINC Events...');
    const res = await axios.get('https://sinc.events/', {
      headers: { 'User-Agent': USER_AGENT },
      timeout: 12000
    });
    const html = res.data;

    // Check for JSON-LD structured data first
    const jsonLdRegex = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
    let ldMatch;
    while ((ldMatch = jsonLdRegex.exec(html)) !== null) {
      try {
        const parsed = JSON.parse(ldMatch[1]);
        const items = Array.isArray(parsed) ? parsed : [parsed];
        for (const item of items) {
          if (item['@type'] === 'Event' || item.type === 'Event') {
            events.push({
              title: item.name || item.headline,
              description: item.description || 'Experience the vibe in Kigali with SINC Events.',
              venue: item.location?.name || item.location?.address || 'Kigali, Rwanda',
              category: normalizeCategory('', item.name, item.description),
              date: item.startDate ? new Date(item.startDate) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
              endDate: item.endDate ? new Date(item.endDate) : null,
              bannerImage: item.image?.url || item.image || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
              organizerName: item.organizer?.name || 'SINC Events',
              price: item.offers?.price ? parseFloat(item.offers.price) : 0,
              isTicketed: true,
              priceRange: item.offers?.price ? `${item.offers.price} RWF` : 'Tickets on SINC',
              externalTicketLink: item.url || 'https://sinc.events/',
              sourcePlatform: 'sinc.events',
              sourceUrl: item.url || 'https://sinc.events/'
            });
          }
        }
      } catch (e) {
        // Skip unparseable JSON-LD
      }
    }

    // Fallback: parse HTML event cards / anchor links
    if (events.length === 0) {
      const eventHrefRegex = /<a[^>]*href="(\/event\/[^"]+|\/events\/[^"]+|https:\/\/sinc\.events\/event\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      let cardMatch;
      while ((cardMatch = eventHrefRegex.exec(html)) !== null) {
        const rawLink = cardMatch[1];
        const fullUrl = rawLink.startsWith('http') ? rawLink : `https://sinc.events${rawLink}`;
        const content = cardMatch[2];

        const titleMatch = /<h\d[^>]*>(.*?)<\/h\d>|<div[^>]*class="[^"]*title[^"]*"[^>]*>(.*?)<\/div>/i.exec(content);
        const imgMatch = /<img[^>]*src="([^"]+)"/i.exec(content);
        const dateMatch = /(\w{3,9}\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|\d{1,2}\s+\w{3,9}\s+\d{4})/i.exec(content);

        const title = (titleMatch ? (titleMatch[1] || titleMatch[2]) : '').replace(/<[^>]*>/g, '').trim();
        if (title && title.length > 3) {
          events.push({
            title,
            description: `Exciting event hosted in Kigali. Discover and book on SINC Events Rwanda.`,
            venue: 'Kigali, Rwanda',
            category: normalizeCategory('', title, ''),
            date: dateMatch ? new Date(dateMatch[1]) : new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
            bannerImage: imgMatch ? imgMatch[1] : 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80',
            organizerName: 'SINC Events Partner',
            price: 0,
            isTicketed: true,
            priceRange: 'Buy on SINC',
            externalTicketLink: fullUrl,
            sourcePlatform: 'sinc.events',
            sourceUrl: fullUrl
          });
        }
      }
    }
  } catch (err) {
    console.error('[Aggregator] Error scraping SINC Events:', err.message);
  }
  return events;
}

/**
 * 3. Scrape Events from EventsBash Rwanda (https://eventsbash.rw/)
 */
async function scrapeEventsBash() {
  const events = [];
  try {
    console.log('[Aggregator] Fetching EventsBash Rwanda...');
    const res = await axios.get('https://eventsbash.rw/', {
      headers: { 'User-Agent': USER_AGENT },
      timeout: 12000
    });
    const html = res.data;

    // Parse JSON-LD or event cards
    const jsonLdRegex = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
    let ldMatch;
    while ((ldMatch = jsonLdRegex.exec(html)) !== null) {
      try {
        const parsed = JSON.parse(ldMatch[1]);
        const items = Array.isArray(parsed) ? parsed : (parsed['@graph'] || [parsed]);
        for (const item of items) {
          if (item['@type'] === 'Event' || item.type === 'Event') {
            events.push({
              title: item.name || 'EventsBash Event',
              description: item.description || 'Upcoming Kigali event on EventsBash Rwanda.',
              venue: item.location?.name || 'Kigali, Rwanda',
              category: normalizeCategory('', item.name, item.description),
              date: item.startDate ? new Date(item.startDate) : new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
              bannerImage: item.image || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
              organizerName: item.organizer?.name || 'EventsBash Rwanda',
              price: item.offers?.price ? parseFloat(item.offers.price) : 0,
              isTicketed: true,
              priceRange: 'Tickets on EventsBash',
              externalTicketLink: item.url || 'https://eventsbash.rw/',
              sourcePlatform: 'eventsbash.rw',
              sourceUrl: item.url || 'https://eventsbash.rw/'
            });
          }
        }
      } catch (e) {
        // Skip
      }
    }

    // Fallback: parse link cards
    if (events.length === 0) {
      const cardRegex = /<a[^>]*href="(\/event\/[^"]+|\/events\/[^"]+|https:\/\/eventsbash\.rw\/event\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      let match;
      while ((match = cardRegex.exec(html)) !== null) {
        const rawLink = match[1];
        const fullUrl = rawLink.startsWith('http') ? rawLink : `https://eventsbash.rw${rawLink}`;
        const content = match[2];

        const titleMatch = /<h\d[^>]*>(.*?)<\/h\d>|<div[^>]*class="[^"]*(?:title|event-name)[^"]*"[^>]*>(.*?)<\/div>/i.exec(content);
        const imgMatch = /<img[^>]*src="([^"]+)"/i.exec(content);
        const venueMatch = /<span[^>]*class="[^"]*(?:venue|location)[^"]*"[^>]*>(.*?)<\/span>/i.exec(content);

        const title = (titleMatch ? (titleMatch[1] || titleMatch[2]) : '').replace(/<[^>]*>/g, '').trim();
        if (title && title.length > 3) {
          events.push({
            title,
            description: `Discover ${title} happening in Kigali on EventsBash Rwanda.`,
            venue: venueMatch ? venueMatch[1].replace(/<[^>]*>/g, '').trim() : 'Kigali, Rwanda',
            category: normalizeCategory('', title, ''),
            date: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000),
            bannerImage: imgMatch ? imgMatch[1] : 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=800&q=80',
            organizerName: 'EventsBash Organizer',
            price: 0,
            isTicketed: true,
            priceRange: 'Tickets on EventsBash',
            externalTicketLink: fullUrl,
            sourcePlatform: 'eventsbash.rw',
            sourceUrl: fullUrl
          });
        }
      }
    }
  } catch (err) {
    console.error('[Aggregator] Error scraping EventsBash:', err.message);
  }
  return events;
}

/**
 * Runs all scrapers and imports new unique events into the Moderation Queue
 */
async function importAllExternalEvents() {
  console.log('[Aggregator] Starting multi-platform Rwanda events sync...');

  // Find or use admin user as default manager
  let admin = await User.findOne({ role: 'Admin' });
  if (!admin) {
    admin = await User.findOne();
  }
  const managerId = admin ? admin._id : null;

  // Run all scrapers concurrently
  const [bkEvents, sincEvents, bashEvents] = await Promise.all([
    scrapeBkArena().catch(err => { console.error(err); return []; }),
    scrapeSincEvents().catch(err => { console.error(err); return []; }),
    scrapeEventsBash().catch(err => { console.error(err); return []; })
  ]);

  const allFound = [...bkEvents, ...sincEvents, ...bashEvents];
  console.log(`[Aggregator] Scraped total: ${allFound.length} events (BK Arena: ${bkEvents.length}, SINC: ${sincEvents.length}, EventsBash: ${bashEvents.length})`);

  let newImportedCount = 0;
  let skippedCount = 0;
  const importedEvents = [];

  for (const item of allFound) {
    if (!item.title || item.title.trim().length < 3) continue;

    // Check if event already exists by sourceUrl or exact title
    const existing = await Event.findOne({
      $or: [
        { sourceUrl: item.sourceUrl },
        { title: new RegExp(`^${item.title.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
      ]
    });

    if (existing) {
      skippedCount++;
      continue;
    }

    // Insert as Pending Moderation
    const newEvent = new Event({
      title: item.title.trim(),
      description: item.description || `Exciting upcoming event in Kigali: ${item.title}.`,
      category: item.category || 'Music & Concerts',
      venue: item.venue || 'Kigali, Rwanda',
      organizerName: item.organizerName || 'Rwanda Events',
      date: item.date || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      endDate: item.endDate,
      price: item.price || 0,
      priceRange: item.priceRange || 'Tickets Available',
      bannerImage: item.bannerImage || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
      manager: managerId,
      isFeatured: false,
      isTicketed: true,
      externalTicketLink: item.externalTicketLink,
      status: 'Pending_Moderation',
      sourcePlatform: item.sourcePlatform,
      sourceUrl: item.sourceUrl,
      importedAt: new Date()
    });

    await newEvent.save();
    importedEvents.push(newEvent);
    newImportedCount++;
  }

  console.log(`[Aggregator] Import complete! New imported: ${newImportedCount}, Already existed: ${skippedCount}`);
  return {
    totalScraped: allFound.length,
    newImported: newImportedCount,
    alreadyExisted: skippedCount,
    importedEvents,
    breakdown: {
      bkArena: bkEvents.length,
      sincEvents: sincEvents.length,
      eventsBash: bashEvents.length
    }
  };
}

module.exports = {
  scrapeBkArena,
  scrapeSincEvents,
  scrapeEventsBash,
  importAllExternalEvents
};
